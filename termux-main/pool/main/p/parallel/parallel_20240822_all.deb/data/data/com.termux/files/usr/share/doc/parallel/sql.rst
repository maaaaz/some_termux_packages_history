
****
NAME
****


sql - execute a command on a database determined by a dburl


********
SYNOPSIS
********


\ **sql**\  [options] \ *dburl*\  [\ *commands*\ ]

\ **sql**\  [options] \ *dburl*\  < commandfile

\ **#!/usr/bin/sql**\  \ **--shebang**\  [options] \ *dburl*\ 


***********
DESCRIPTION
***********


GNU \ **sql**\  aims to give a simple, unified interface for accessing databases through all the different databases' command line clients. So far the focus has been on giving a common way to specify login information (protocol, username, password, hostname, and port number), size (database and table size), and running queries.

The database is addressed using a DBURL. If \ *commands*\  are left out you will get that database's interactive shell.

GNU \ **sql**\  is often used in combination with GNU \ **parallel**\ .


- \ *dburl*\ 
 
 A DBURL has the following syntax: [sql:]vendor:// [[user][:password]@][host][:port]/[database][?sqlquery]
 
 See the section DBURL below.
 


- \ *commands*\ 
 
 The SQL commands to run. Each argument will have a newline appended.
 
 Example: "SELECT \* FROM foo;" "SELECT \* FROM bar;"
 
 If the arguments contain '\\n' or '\\x0a' this will be replaced with a newline:
 
 Example: "SELECT \* FROM foo;\\n SELECT \* FROM bar;"
 
 If no commands are given SQL is read from the keyboard or STDIN.
 
 Example: echo 'SELECT \* FROM foo;' | sql mysql:///
 


- \ **--csv**\ 
 
 CSV output.
 


- \ **--db-size**\ 



- \ **--dbsize**\ 
 
 Size of database. Show the size of the database on disk. For Oracle this requires access to read the table \ *dba_data_files*\  - the user \ *system*\  has that.
 


- \ **--help**\ 



- \ **-h**\ 
 
 Print a summary of the options to GNU \ **sql**\  and exit.
 


- \ **--html**\ 
 
 HTML output. Turn on HTML tabular output.
 


- \ **--json**\ 



- \ **--pretty**\ 
 
 Pretty JSON output.
 


- \ **--list-databases**\ 



- \ **--listdbs**\ 



- \ **--show-databases**\ 



- \ **--showdbs**\ 
 
 List the databases (table spaces) in the database.
 


- \ **--listproc**\ 



- \ **--proclist**\ 



- \ **--show-processlist**\ 
 
 Show the list of running queries.
 


- \ **--list-tables**\ 



- \ **--show-tables**\ 



- \ **--table-list**\ 
 
 List the tables in the database.
 


- \ **--noheaders**\ 



- \ **--no-headers**\ 



- \ **-n**\ 
 
 Remove headers and footers and print only tuples. Bug in Oracle: it still prints number of rows found.
 


- \ **-p**\  \ *pass-through*\ 
 
 The string following -p will be given to the database connection program as arguments. Multiple -p's will be joined with space. Example: pass '-U' and the user name to the program:
 
 \ *-p "-U scott"*\  can also be written \ *-p -U -p scott*\ .
 


- \ **--precision**\  <\ *rfc3339|h|m|s|ms|u|ns*\ >
 
 Precision of timestamps.
 
 Specifiy the format of the output timestamps: rfc3339, h, m, s, ms, u or ns.
 


- \ **-r**\ 
 
 Try 3 times. Short version of \ *--retries 3*\ .
 


- \ **--retries**\  \ *ntimes*\ 
 
 Try \ *ntimes*\  times. If the client program returns with an error, retry the command. Default is \ *--retries 1*\ .
 


- \ **--sep**\  \ *string*\ 



- \ **-s**\  \ *string*\ 
 
 Field separator. Use \ *string*\  as separator between columns.
 


- \ **--skip-first-line**\ 
 
 Do not use the first line of input (used by GNU \ **sql**\  itself when called with \ **--shebang**\ ).
 


- \ **--table-size**\ 



- \ **--tablesize**\ 
 
 Size of tables. Show the size of the tables in the database.
 


- \ **--verbose**\ 



- \ **-v**\ 
 
 Print which command is sent.
 


- \ **--version**\ 



- \ **-V**\ 
 
 Print the version GNU \ **sql**\  and exit.
 


- \ **--shebang**\ 



- \ **-Y**\ 
 
 GNU \ **sql**\  can be called as a shebang (#!) command as the first line of a script. Like this:
 
 
 .. code-block:: bash
 
    #!/usr/bin/sql -Y mysql:///
  
    SELECT * FROM foo;
 
 
 For this to work \ **--shebang**\  or \ **-Y**\  must be set as the first option.
 



*****
DBURL
*****


A DBURL has the following syntax: [sql:]vendor:// [[user][:password]@][host][:port]/[database][?sqlquery]

To quote special characters use %-encoding specified in http://tools.ietf.org/html/rfc3986#section-2.1 (E.g. a password containing '/' would contain '%2F').

Examples:


.. code-block:: perl

  mysql://scott:tiger@my.example.com/mydb
  influxdb://scott:tiger@influxdb.example.com/foo
  sql:oracle://scott:tiger@ora.example.com/xe
  postgresql://scott:tiger@pg.example.com/pgdb
  pg:///
  postgresqlssl://scott@pg.example.com:3333/pgdb
  sql:sqlite2:////tmp/db.sqlite?SELECT * FROM foo;
  sqlite3:///../db.sqlite3?SELECT%20*%20FROM%20foo;


Currently supported vendors: MySQL (mysql), MySQL with SSL (mysqls, mysqlssl), Oracle (oracle, ora), PostgreSQL (postgresql, pg, pgsql, postgres), PostgreSQL with SSL (postgresqlssl, pgs, pgsqlssl, postgresssl, pgssl, postgresqls, pgsqls, postgress), SQLite2 (sqlite, sqlite2), SQLite3 (sqlite3), InfluxDB 1.x (influx, influxdb), InfluxDB with SSL (influxdbssl, influxdbs, influxs, influxssl)

Aliases must start with ':' and are read from /etc/sql/aliases and ~/.sql/aliases. The user's own ~/.sql/aliases should only be readable by the user.

Example of aliases:


.. code-block:: perl

  :myalias1 pg://scott:tiger@pg.example.com/pgdb
  :myalias2 ora://scott:tiger@ora.example.com/xe
  # Short form of mysql://`whoami`:nopassword@localhost:3306/`whoami`
  :myalias3 mysql:///
  # Short form of mysql://`whoami`:nopassword@localhost:33333/mydb
  :myalias4 mysql://:33333/mydb
  # Alias for an alias
  :m      :myalias4
  # the sortest alias possible
  :       sqlite2:////tmp/db.sqlite
  # Including an SQL query
  :query  sqlite:////tmp/db.sqlite?SELECT * FROM foo;



********
EXAMPLES
********


Get an interactive prompt
=========================


The most basic use of GNU \ **sql**\  is to get an interactive prompt:

\ **sql sql:oracle://scott:tiger@ora.example.com/xe**\ 

If you have setup an alias you can do:

\ **sql :myora**\ 


Run a query
===========


To run a query directly from the command line:

\ **sql :myalias "SELECT \* FROM foo;"**\ 

Oracle requires newlines after each statement. This can be done like this:

\ **sql :myora "SELECT \* FROM foo;" "SELECT \* FROM bar;"**\ 

Or this:

\ **sql :myora "SELECT \* FROM foo;\\nSELECT \* FROM bar;"**\ 


Copy a PostgreSQL database
==========================


To copy a PostgreSQL database use pg_dump to generate the dump and GNU \ **sql**\  to import it:

\ **pg_dump pg_database | sql pg://scott:tiger@pg.example.com/pgdb**\ 


Empty all tables in a MySQL database
====================================


Using GNU \ **parallel**\  it is easy to empty all tables without dropping them:

\ **sql -n mysql:/// 'show tables' | parallel sql mysql:/// DELETE FROM {};**\ 


Drop all tables in a PostgreSQL database
========================================


To drop all tables in a PostgreSQL database do:

\ **sql -n pg:/// '\\dt' | parallel --colsep '\\|' -r sql pg:/// DROP TABLE {2};**\ 


Run as a script
===============


Instead of doing:

\ **sql mysql:/// < sqlfile**\ 

you can combine the sqlfile with the DBURL to make a UNIX-script. Create a script called \ *demosql*\ :

\ **#!/usr/bin/sql -Y mysql:///**\ 

\ **SELECT \* FROM foo;**\ 

Then do:

\ **chmod +x demosql; ./demosql**\ 


Use --colsep to process multiple columns
========================================


Use GNU \ **parallel**\ 's \ **--colsep**\  to separate columns:

\ **sql -s '\\t' :myalias 'SELECT \* FROM foo;' | parallel --colsep '\\t' do_stuff {4} {1}**\ 


Retry if the connection fails
=============================


If the access to the database fails occasionally \ **--retries**\  can help make sure the query succeeds:

\ **sql --retries 5 :myalias 'SELECT \* FROM really_big_foo;'**\ 


Get info about the running database system
==========================================


Show how big the database is:

\ **sql --db-size :myalias**\ 

List the tables:

\ **sql --list-tables :myalias**\ 

List the size of the tables:

\ **sql --table-size :myalias**\ 

List the running processes:

\ **sql --show-processlist :myalias**\ 



**************
REPORTING BUGS
**************


GNU \ **sql**\  is part of GNU \ **parallel**\ . Report bugs to <bug-parallel@gnu.org>.


******
AUTHOR
******


When using GNU \ **sql**\  for a publication please cite:

O. Tange (2011): GNU SQL - A Command Line Tool for Accessing Different Databases Using DBURLs, ;login: The USENIX Magazine, April 2011:29-32.

Copyright (C) 2008-2010 Ole Tange http://ole.tange.dk

Copyright (C) 2010-2024 Ole Tange, http://ole.tange.dk and Free Software Foundation, Inc.


*******
LICENSE
*******


This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version 3 of the License, or at your option any later version.

This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with this program.  If not, see <http://www.gnu.org/licenses/>.

Documentation license I
=======================


Permission is granted to copy, distribute and/or modify this documentation under the terms of the GNU Free Documentation License, Version 1.3 or any later version published by the Free Software Foundation; with no Invariant Sections, with no Front-Cover Texts, and with no Back-Cover Texts.  A copy of the license is included in the file LICENSES/GFDL-1.3-or-later.txt.


Documentation license II
========================


You are free:


- \ **to Share**\ 
 
 to copy, distribute and transmit the work
 


- \ **to Remix**\ 
 
 to adapt the work
 


Under the following conditions:


- \ **Attribution**\ 
 
 You must attribute the work in the manner specified by the author or licensor (but not in any way that suggests that they endorse you or your use of the work).
 


- \ **Share Alike**\ 
 
 If you alter, transform, or build upon this work, you may distribute the resulting work only under the same, similar or a compatible license.
 


With the understanding that:


- \ **Waiver**\ 
 
 Any of the above conditions can be waived if you get permission from the copyright holder.
 


- \ **Public Domain**\ 
 
 Where the work or any of its elements is in the public domain under applicable law, that status is in no way affected by the license.
 


- \ **Other Rights**\ 
 
 In no way are any of the following rights affected by the license:
 
 
 - 
  
  Your fair dealing or fair use rights, or other applicable copyright exceptions and limitations;
  
 
 
 - 
  
  The author's moral rights;
  
 
 
 - 
  
  Rights other persons may have either in the work itself or in how the work is used, such as publicity or privacy rights.
  
 
 


- \ **Notice**\ 
 
 For any reuse or distribution, you must make clear to others the license terms of this work.
 


A copy of the full license is included in the file as cc-by-sa.txt.



************
DEPENDENCIES
************


GNU \ **sql**\  uses Perl. If \ **mysql**\  is installed, MySQL dburls will work. If \ **psql**\  is installed, PostgreSQL dburls will work.  If \ **sqlite**\  is installed, SQLite2 dburls will work.  If \ **sqlite3**\  is installed, SQLite3 dburls will work. If \ **sqlplus**\  is installed, Oracle dburls will work. If \ **rlwrap**\  is installed, GNU \ **sql**\  will have a command history for Oracle.


*****
FILES
*****


~/.sql/aliases - user's own aliases with DBURLs

/etc/sql/aliases - common aliases with DBURLs


********
SEE ALSO
********


\ **mysql**\ (1), \ **psql**\ (1), \ **rlwrap**\ (1), \ **sqlite**\ (1), \ **sqlite3**\ (1), \ **sqlplus**\ (1), \ **influx**\ (1)


.. code-block:: bash

     # This must be done first as this may exec myself
     if(defined $ARGV[0] and ($ARGV[0]=~/^-Y/ or $ARGV[0]=~/^--shebang /)) {
 	# Program is called from #! line in script
 	$ARGV[0]=~s/^-Y //; # remove -Y if on its own
 	$ARGV[0]=~s/^-Y/-/; # remove -Y if bundled with other options
 	$ARGV[0]=~s/^--shebang //; # remove --shebang if it is set
 	my $argfile = pop @ARGV;
 	# exec myself to split @ARGV into separate fields
 	exec "$0 --skip-first-line < $argfile @ARGV";
 =for pod2rst next-code-block: bash
 
     }
     Getopt::Long::Configure ("bundling","require_order");
     GetOptions("passthrough|p=s@" => \$::opt_p,
 	       "sep|s=s" => \\$::opt_s,
 	       "html" => \\$::opt_html,
 	       "show-processlist|proclist|listproc|showqueries|show-queries"
 	       => \\$::opt_processlist,
 	       "show-tables|showtables|listtables|list-tables|".
 	       "tablelist|table-list|show-measurements|showmeasurements|".
 	       "list-measurements|listmeasurements" => \\$::opt_tablelist,
 	       "dblist|".
 	       "listdb|listdbs|list-db|list-dbs|list-database|".
 	       "list-databases|listdatabases|listdatabase|showdb|".
 	       "showdbs|show-db|show-dbs|show-database|show-databases|".
 	       "showdatabases|showdatabase" => \\$::opt_dblist,
 	       "db-size|dbsize" => \\$::opt_dbsize,
 	       "table-size|tablesize" => \\$::opt_tablesize,
 	       "json|j" => \\$::opt_json,
 	       "pretty" => \\$::opt_pretty,
 	       "csv" => \\$::opt_csv,
 	       "precision=s" => \\$::opt_precision,
 	       "noheaders|no-headers|n" => \\$::opt_n,
 	       "r" => \\$::opt_retry,
 	       "retries=s" => \\$::opt_retries,
 	       "debug|D" => \\$::opt_debug,
 	       # Shebang #!/usr/bin/parallel -Yotheroptions
 	       "Y|shebang" => \\$::opt_shebang,
 	       "skip-first-line" => \\$::opt_skip_first_line,
 	       # GNU requirements
 	       "help|h" => \\$::opt_help,
 	       "version|V" => \\$::opt_version,
 	       "verbose|v" => \\$::opt_verbose,
 	) || die_usage();
 
     if(defined $::opt_help) { usage(); exit(0); }
     if(defined $::opt_version) { version(); exit(0); }
     $Global::debug = $::opt_debug; }


sub database_driver_alias {
    my $driver = shift;
    my %database_driver_alias = ("mysql" => "mysql",
				 "mysqls" => "mysqlssl",
				 "mysqlssl" => "mysqlssl",
				 "oracle" => "oracle",
				 "ora" => "oracle",
				 "oracles" => "oraclessl",
				 "oras" => "oraclessl",
				 "oraclessl" => "oraclessl",
				 "orassl" => "oraclessl",
				 "postgresql" => "postgresql",
				 "pgsql" => "postgresql",
				 "postgres" => "postgresql",
				 "pg" => "postgresql",
				 "postgresqlssl" => "postgresqlssl",
				 "pgsqlssl" => "postgresqlssl",
				 "postgresssl" => "postgresqlssl",
				 "pgssl" => "postgresqlssl",
				 "postgresqls" => "postgresqlssl",
				 "pgsqls" => "postgresqlssl",
				 "postgress" => "postgresqlssl",
				 "pgs" => "postgresqlssl",
				 "sqlite" => "sqlite",
				 "sqlite2" => "sqlite",
				 "sqlite3" => "sqlite3",
=for pod2rst next-code-block: bash


.. code-block:: perl

                                  "influx" => "influx",
                                  "influxdb" => "influx",
                                  "influxssl" => "influxssl",
                                  "influxdbssl" => "influxssl",
                                  "influxs" => "influxssl",
                                  "influxdbs" => "influxssl",
 	);
     return $database_driver_alias{$driver}; }


sub mysql_commands {
    my ($database_driver,%opt) = (@_);
    find_command_in_path("mysql") || die ("mysql not in path");
    if(defined($::opt_s)) { die "Field separator not implemented for mysql" }
=for pod2rst next-code-block: bash


.. code-block:: perl

     my $password = defined($opt{'password'}) ? "--password=".$opt{'password'} : "";
     my $host = defined($opt{'host'}) ? "--host=".$opt{'host'} : "";
     my $port = defined($opt{'port'}) ? "--port=".$opt{'port'} : "";
     my $user = defined($opt{'user'}) ? "--user=".$opt{'user'} : "";
     my $database = defined($opt{'database'}) ? $opt{'database'} : $ENV{'USER'};
     my $html = defined($::opt_html) ? "--html" : "";
     my $no_headers = defined($::opt_n) ? "--skip-column-names" : "";
     my $ssl = "";
     if ($database_driver eq "mysqlssl") { $ssl="--ssl"; }
     my($credential_fh,$tmp) = tempfile(SUFFIX => ".sql");
     chmod (0600,$tmp);
     print $credential_fh ("[client]\n",
 			  $user && "user=$opt{'user'}\\n",
 			  $password && "password=$opt{'password'}\\n",
 			  $host && "host=$opt{'host'}\\n");
     close $credential_fh;



.. code-block:: bash

     # Prepend with a remover of the credential tempfile
     my $qtmp = shell_quote($tmp);
 =for pod2rst next-code-block: bash
 
     $batch_command =
 	"((sleep 1; rm $qtmp) & ".
 	"mysql --defaults-extra-file=$qtmp $pass_through_options ".
 	"$no_headers $html $ssl $host $user $port $database)";
 =for pod2rst next-code-block: bash
 
     $interactive_command = $batch_command;
     return($batch_command,$interactive_command); }


sub postgresql_commands {
    my ($database_driver,%opt) = (@_);
    find_command_in_path("psql") || die ("psql not in path");
    my $sep = ($::opt_s) ? "-A --field-separator '$::opt_s'" : "";
=for pod2rst next-code-block: bash


.. code-block:: perl

     my $password = defined($opt{'password'}) ?
 	"PGPASSWORD=".$opt{'password'} : "";
     my $host = defined($opt{'host'}) ? "-h ".$opt{'host'} : "";
     my $port = defined($opt{'port'}) ? "-p ".$opt{'port'} : "";
     my $user = defined($opt{'user'}) ? "-U ".$opt{'user'} : "";
     my $database = defined($opt{'database'}) ? "-d ".$opt{'database'} : "";
     my $html = defined($::opt_html) ? "--html" : "";
     my $no_headers = defined($::opt_n) ? "--tuples-only" : "";
     my $ssl = "";
     if ($database_driver eq "postgresqlssl") { $ssl="PGSSLMODE=require"; }
     $batch_command =
 	"$ssl $password psql $pass_through_options $sep $no_headers ".
 	"$html $host $user $port $database";
     $interactive_command = $batch_command;
 
     return($batch_command,$interactive_command); }


sub oracle_commands {
    my ($database_driver,%opt) = (@_);
=for pod2rst next-code-block: bash


.. code-block:: perl

     # oracle://user:pass@grum:1521/XE becomes:
 =for pod2rst next-code-block: bash
 
     # sqlplus 'user/pass@(DESCRIPTION = (ADDRESS = (PROTOCOL = TCP)(HOST = grum)(PORT = 1521)) (CONNECT_DATA =(SERVER = DEDICATED)(SERVICE_NAME = XE) ))'
 =for pod2rst next-code-block: bash
 
     my $sqlplus = find_command_in_path("sqlplus") ||
 	find_command_in_path("sqlplus64") or
 	die("sqlplus/sqlplus64 not in path");
 
     # Readline support: if rlwrap installed run rlwrap sqlplus
     my $rlwrap = find_command_in_path("rlwrap");



.. code-block:: bash

     # Set good defaults in the inifile
 =for pod2rst next-code-block: bash
 
     $Global::Initfile = "/tmp/$$.sql.init";
     open(INIT,">".$Global::Initfile) || die;
     print INIT "SET LINESIZE 32767\n";
 =for pod2rst next-code-block: bash
 
     $::opt_debug and print "SET LINESIZE 32767\n";
 =for pod2rst next-code-block: bash
 
     print INIT "SET WRAP OFF\n";
     $::opt_debug and print "SET WRAP OFF\n";
     if(defined($::opt_html)) {
 	print INIT "SET MARK HTML ON\\n";
 	$::opt_debug and print "SET MARK HTML ON\\n";
     }
     if(defined($::opt_n)) {
 	print INIT "SET PAGES 0\\n";
 	$::opt_debug and print "SET PAGES 0\\n";
     } else {
 	print INIT "SET PAGES 50000\\n";
 	$::opt_debug and print "SET PAGES 50000\\n";
     }
     if(defined($::opt_s)) {
 	print INIT "SET COLSEP $::opt_s\\n";
 	$::opt_debug and print "SET COLSEP $::opt_s\\n";
     }
     close INIT;
 
     my $password = defined($opt{'password'}) ? "/".$opt{'password'} : "";
     my $host = defined($opt{'host'}) ? $opt{'host'} : "localhost";
     my $port = defined($opt{'port'}) ? $opt{'port'} : "1521";
     my $user = defined($opt{'user'}) ? $opt{'user'} : "";
 =for pod2rst next-code-block: bash
 
     # Database is called service in Oracle lingo
     my $service = defined($opt{'database'}) ? "(SERVICE_NAME = ".$opt{'database'}.")" : "";
     my $tns = "(DESCRIPTION = (ADDRESS = (PROTOCOL = TCP)(HOST = $host)(PORT = $port)) ".
 	"(CONNECT_DATA =(SERVER = DEDICATED)$service ))";
     my $ssl = "";
     # -L: Do not re-ask for password if it is wrong
     my $common_options = "-L $pass_through_options ".
 	"'$user$password\\@$tns' \\@$Global::Initfile";
     my $batch_command =	"$sqlplus -S ".$common_options;
     my $interactive_command = "$rlwrap $sqlplus ".$common_options;
     return($batch_command,$interactive_command); }


sub sqlite_commands {
    my ($database_driver,%opt) = (@_);
    if(not find_command_in_path($database_driver)) {
	print STDERR "sql: Database driver '$database_driver' not supported\\n";
	exit 255;
=for pod2rst next-code-block: bash


.. code-block:: perl

     }
     my $sep = defined($::opt_s) ? "-separator '$::opt_s'" : "";
     my $password = defined($opt{'password'}) ? "--password=".$opt{'password'} : "";
     my $host = defined($opt{'host'}) ? "--host=".$opt{'host'} : "";
     my $port = defined($opt{'port'}) ? "--port=".$opt{'port'} : "";
     my $user = defined($opt{'user'}) ? "--user=".$opt{'user'} : "";
     my $database = defined($opt{'database'}) ? $opt{'database'} : "";
     my $html = defined($::opt_html) ? "-html" : "";
     my $no_headers = defined($::opt_n) ? "-noheader" : "-header";
     my $ssl = "";
     $batch_command =
 	"$database_driver $pass_through_options $sep ".
 	"$no_headers $html $database";
     $interactive_command = $batch_command;
     return($batch_command,$interactive_command); }


sub influx_commands {
    my ($database_driver,%opt) = (@_);
    my $influx = find_command_in_path("influx") ||
	die ("influx not in path");
    if(defined($::opt_s)) {
	die "Field separator not implemented for influx";
=for pod2rst next-code-block: bash


.. code-block:: perl

     }
     my $password =
 	defined($opt{'password'}) ? "-password=".$opt{'password'} : "";
     my $host = defined($opt{'host'}) ? "-host=".$opt{'host'} : "";
     my $port = defined($opt{'port'}) ? "-port=".$opt{'port'} : "";
     my $user = defined($opt{'user'}) ? "-username=".$opt{'user'} : "";
     my $database = defined($opt{'database'}) ?
 	"-database $opt{'database'}" : "-database $ENV{'USER'}";
 
     my $format = defined($::opt_json) ? "-format json" :
                  defined($::opt_pretty) ? "-format json -pretty" :
                  defined($::opt_csv) ? "-format csv" : "";
     my $precision = defined($::opt_precision) ?
 	"-precision $::opt_precision" : "";
 
     my $no_headers = defined($::opt_n) ? "--skip-column-names" : "";
     my $ssl = "";
     if($database_driver eq "influxssl") { $ssl="--ssl"; }



.. code-block:: bash

     $batch_command =
 =for pod2rst next-code-block: bash
 
         "$influx $pass_through_options $no_headers $format ".
 	"$precision $ssl $host $user $password $port  $database";
 =for pod2rst next-code-block: bash
 
     $interactive_command = $batch_command;
 =for pod2rst next-code-block: bash
 
     return($batch_command,$interactive_command); }


sub processlist {
    my $dbdriver = shift;
    my %dburl = @_;
    my %statement =
	("mysql" => "show processlist;",
	 "postgresql" => ("SELECT ".
			  "    datname AS database,".
			  "    usename AS username,".
			  "    now()-xact_start AS runtime,".
			  "    current_query ".
			  "FROM pg_stat_activity ".
			  "ORDER BY runtime DESC;"),
	 "oracle" => ("SELECT ".
		      '    CPU_TIME/100000, SYS.V_$SQL.SQL_TEXT, USERNAME '.
		      "FROM ".
		      '    SYS.V_$SQL, SYS.V_$SESSION '.
		      "WHERE ".
		      '    SYS.V_$SQL.SQL_ID = SYS.V_$SESSION.SQL_ID(+) '.
		      "AND username IS NOT NULL ".
		      "ORDER BY CPU_TIME DESC;"),
	 "influx" => "show queries;",
	);
=for pod2rst next-code-block: bash


.. code-block:: perl

     if($statement{$dbdriver}) {
 	return $statement{$dbdriver};
     } else {
 	print STDERR "processlist is not implemented for $dbdriver\\n";
 	exit 1;
     } }


sub tablelist {
    my $dbdriver = shift;
    my %dburl = @_;
    my %statement =
	("mysql" => "show tables;",
	 "postgresql" => '\\dt',
	 "oracle" => ("SELECT object_name ".
		      "FROM user_objects ".
		      "WHERE object_type = 'TABLE';"),
	 "sqlite" => ".tables",
	 "sqlite3" => ".tables",
	 "influx" => "show measurements;",
	);
=for pod2rst next-code-block: bash


.. code-block:: perl

     if($statement{$dbdriver}) {
 	return $statement{$dbdriver};
     } else {
 	print STDERR "tablelist is not implemented for $dbdriver\\n";
 	exit 1;
     } }


sub dblist {
    my $dbdriver = shift;
    my %dburl = @_;
    my %statement =
	("mysql" => "show databases;",
	 "postgresql" => ("SELECT datname FROM pg_database ".
			  "WHERE datname NOT IN ('template0','template1','postgres') ".
			  "ORDER BY datname ASC;"),
	 "oracle" => ("select \* from user_tablespaces;"),
	 "influx" => "show databases;",
	);
=for pod2rst next-code-block: bash


.. code-block:: perl

     if($statement{$dbdriver}) {
 	return $statement{$dbdriver};
     } else {
 	print STDERR "dblist is not implemented for $dbdriver\\n";
 	exit 1;
     } }


sub dbsize {
    my $dbdriver = shift;
    my %dburl = @_;
    my %statement;
    if(defined $dburl{'database'}) {
	%statement =
	    ("mysql" => (
		 'SELECT '.
		 '    table_schema "database", '.
		 '    SUM(data_length+index_length) "bytes", '.
		 '    SUM(data_length+index_length)/1024/1024 "megabytes" '.
		 'FROM information_schema.TABLES '.
		 "WHERE table_schema = '$dburl{'database'}'".
		 'GROUP BY table_schema;'),
	     "postgresql" => (
		 "SELECT '$dburl{'database'}' AS database, ".
		 "pg_database_size('$dburl{'database'}') AS bytes, ".
		 "pg_size_pretty(pg_database_size('$dburl{'database'}')) AS human_readabable "),
	     "sqlite" => (
		 "SELECT ".(undef_as_zero(-s $dburl{'database'}))." AS bytes;"),
	     "sqlite3" => (
		 "SELECT ".(undef_as_zero(-s $dburl{'database'}))." AS bytes;"),
	    );
=for pod2rst next-code-block: bash


.. code-block:: perl

     } else {
 	%statement =
 	    ("mysql" => (
 		 'SELECT '.
 		 '    table_schema "database", '.
 		 '    SUM(data_length+index_length) "bytes", '.
 		 '    SUM(data_length+index_length)/1024/1024 "megabytes" '.
 		 'FROM information_schema.TABLES '.
 		 'GROUP BY table_schema;'),
 	     "postgresql" => (
 		 'SELECT datname AS database, pg_database_size(datname) AS bytes, '.
 		 'pg_size_pretty(pg_database_size(datname)) AS human_readabable '.
 		 'FROM (SELECT datname FROM pg_database) a;'),
 	     "sqlite" => (
 		 "SELECT 0 AS bytes;"),
 	     "sqlite3" => (
 		 "SELECT 0 AS bytes;"),
 	    );
     }
     if($statement{$dbdriver}) {
 	return $statement{$dbdriver};
     } else {
 	print STDERR "dbsize is not implemented for $dbdriver\\n";
 	exit 1;
     } }


sub tablesize {
    my $dbdriver = shift;
    my $database = shift;
    my %statement =
	("postgresql" => (
	     "SELECT relname, relpages\*8 AS kb, reltuples::int AS \\"live+dead rows\\" ".
	     "FROM pg_class c ".
	     "ORDER BY relpages DESC;"),
	 "mysql" => (
	     "select table_name, TABLE_ROWS, DATA_LENGTH,INDEX_LENGTH from INFORMATION_SCHEMA.tables;"),
	);
=for pod2rst next-code-block: bash


.. code-block:: perl

     if($statement{$dbdriver}) {
 	return $statement{$dbdriver};
     } else {
 	print STDERR "table size is not implemented for $dbdriver\\n";
 	exit 1;
     } }


sub is_stdin_terminal {
    return (-t STDIN); }

sub find_command_in_path {
=for pod2rst next-code-block: bash


.. code-block:: perl

     # Find the command if it exists in the current path
     my $command = shift;
     my $path = `which $command`;
     chomp $path;
     return $path; }


sub get_alias {
    my $alias = shift;
=for pod2rst next-code-block: bash


.. code-block:: perl

     $alias =~ s/^(sql:)*//; # Accept aliases prepended with sql:
     if ($alias !~ /^:/) {
 	return $alias;
 =for pod2rst next-code-block: bash
 
     }
 
     # Find the alias
     my $path;
     if (-l $0) {
 	($path) = readlink($0) =~ m|^(.*)/|;
 =for pod2rst next-code-block: bash
 
     } else {
 	($path) = $0 =~ m|^(.*)/|;
 =for pod2rst next-code-block: bash
 
     }
 
     my @deprecated = ("$ENV{HOME}/.dburl.aliases",
 		      "$path/dburl.aliases", "$path/dburl.aliases.dist");
     for (@deprecated) {
 	if(-r $_) {
 	    print STDERR "$_ is deprecated. Use .sql/aliases instead (read man sql)\\n";
 	}
 =for pod2rst next-code-block: bash
 
     }
     my @urlalias=();
     check_permissions("$ENV{HOME}/.sql/aliases");
     check_permissions("$ENV{HOME}/.dburl.aliases");
     my @search = ("$ENV{HOME}/.sql/aliases",
 		  "$ENV{HOME}/.dburl.aliases", "/etc/sql/aliases",
 		  "$path/dburl.aliases", "$path/dburl.aliases.dist");
     for my $alias_file (@search) {
 	if(-r $alias_file) {
 	    open(my $fh, "<", $alias_file) || die;
 	    push @urlalias, <$fh>;
 	    close $fh;
 	}
     }
     my ($alias_part,$rest) = $alias=~/(:\w*)(.*)/;
     # If we saw this before: we have an alias loop
     if(grep {$_ eq $alias_part } @Private::seen_aliases) {
 	print STDERR "$alias_part is a cyclic alias\\n";
 	exit -1;
     } else {
 	push @Private::seen_aliases, $alias_part;
     }
 
     my $dburl;
     for (@urlalias) {
 	/^$alias_part\\s+(\\S+.*)/ and do { $dburl = $1; last; }
 =for pod2rst next-code-block: bash
 
     }
 
     if($dburl) {
 	return get_alias($dburl.$rest);
 =for pod2rst next-code-block: bash
 
     } else {
 	usage("$alias is not defined in @search");
 	exit(-1);
 =for pod2rst next-code-block: bash
 
     } }


sub check_permissions {
    my $file = shift;


.. code-block:: perl

     if(-e $file) {
 	if(not -o $file) {
 	    my $username = (getpwuid($<))[0];
 	    print STDERR "$file should be owned by $username: chown $username $file\\n";
 	}
 	my ($dev,$ino,$mode,$nlink,$uid,$gid,$rdev,$size,
 	    $atime,$mtime,$ctime,$blksize,$blocks) = stat($file);
 	if($mode & 077) {
 	    my $username = (getpwuid($<))[0];
 	    print STDERR "$file should be only be readable by $username: chmod 600 $file\\n";
 	}
 =for pod2rst next-code-block: bash
 
     } }


sub parse_dburl {
    my $url = shift;
    my %options = ();
=for pod2rst next-code-block: bash


.. code-block:: perl

     # sql:mysql://[[user][:password]@][host][:port]/[database[?sql query]]
 
     if($url=~m!(?:sql:)? # You can prefix with 'sql:'
 =for pod2rst next-code-block: bash
 
                ((?:oracle|ora|mysql|pg|postgres|postgresql|influx|influxdb)(?:s|ssl|)|
 =for pod2rst next-code-block: bash
 
                  (?:sqlite|sqlite2|sqlite3)):// # Databasedriver ($1)
 =for pod2rst next-code-block: bash
 
                (?:
                 ([^:@/][^:@]*|) # Username ($2)
                 (?:
                  :([^@]*) # Password ($3)
                 )?
                @)?
                ([^:/]*)? # Hostname ($4)
                (?:
                 :
                 ([^/]*)? # Port ($5)
                )?
                (?:
                 /
                 ([^?/]*)? # Database ($6)
                )?
                (?:
                 /?
                 \?
                 (.*)? # Query ($7)
                )?
               !x) {
 	$options{databasedriver} = undef_if_empty(uri_unescape($1));
 	$options{user} = undef_if_empty(uri_unescape($2));
 	$options{password} = undef_if_empty(uri_unescape($3));
 	$options{host} = undef_if_empty(uri_unescape($4));
 	$options{port} = undef_if_empty(uri_unescape($5));
 	$options{database} = undef_if_empty(uri_unescape($6))
 	    || $options{user};
 	$options{query} = undef_if_empty(uri_unescape($7));
 	debug("dburl $url\\n");
 	debug("databasedriver ",$options{databasedriver}, " user ", $options{user},
 	      " password ", $options{password}, " host ", $options{host},
 	      " port ", $options{port}, " database ", $options{database},
 	      " query ",$options{query}, "\\n");
     } else {
 	usage("$url is not a valid DBURL");
 	exit -1;
     }
     return %options; }


sub uri_unescape {
=for pod2rst next-code-block: bash


.. code-block:: perl

     # Copied from http://cpansearch.perl.org/src/GAAS/URI-1.55/URI/Escape.pm
 =for pod2rst next-code-block: bash
 
     # to avoid depending on URI::Escape
 =for pod2rst next-code-block: bash
 
     # This section is (C) Gisle Aas.
 =for pod2rst next-code-block: bash
 
     # Note from RFC1630:  "Sequences which start with a percent sign
 =for pod2rst next-code-block: bash
 
     # but are not followed by two hexadecimal characters are reserved
     # for future extension"
     my $str = shift;
     if (@_ && wantarray) {
 	# not executed for the common case of a single argument
 	my @str = ($str, @_);  # need to copy
 	foreach (@str) {
 	    s/%([0-9A-Fa-f]{2})/chr(hex($1))/eg;
 	}
 	return @str;
     }
     $str =~ s/%([0-9A-Fa-f]{2})/chr(hex($1))/eg if defined $str;
     $str; }


sub undef_if_empty {
    if(defined($_[0]) and $_[0] eq "") {
	return undef;
=for pod2rst next-code-block: bash


.. code-block:: perl

     }
     return $_[0]; }


sub undef_as_zero {
    my $a = shift;
    return $a ? $a : 0; }

sub version {
=for pod2rst next-code-block: bash


.. code-block:: perl

     # Returns: N/A
     print join("\n",
 	       "GNU $Global::progname $Global::version",
 	       "Copyright (C) 2009,2010,2011,2012,2013,2014,2015,2016,2017",
 	       "Ole Tange and Free Software Foundation, Inc.",
 	       "License GPLv3+: GNU GPL version 3 or later <http://gnu.org/licenses/gpl.html>",
 	       "This is free software: you are free to change and redistribute it.",
 	       "GNU $Global::progname comes with no warranty.",
 	       "",
 	       "Web site: http://www.gnu.org/software/${Global::progname}\\n",
 	       "When using GNU $Global::progname for a publication please cite:\\n",
 	       "O. Tange (2011): GNU SQL - A Command Line Tool for Accessing Different",
 	       "Databases Using DBURLs, ;login: The USENIX Magazine, April 2011:29-32.\\n"
 	); }


sub die_usage {
=for pod2rst next-code-block: bash


.. code-block:: perl

     # Returns: N/A
     usage();
     exit(255); }


sub usage {
=for pod2rst next-code-block: bash


.. code-block:: perl

     # Returns: N/A
     if(@_) {
 	print map{ "$Global::progname: Error: $_\\n" } @_;
 	print "\\n";
 =for pod2rst next-code-block: bash
 
     }
     print "Usage:\n";
     print "$Global::progname [-hnr] [--table-size] [--db-size] [-p pass-through] [-s string] dburl [sqlcommand]\n";
 =for pod2rst next-code-block: bash
 
     print "$Global::progname [-hnr] [--table-size] [--db-size] [-p pass-through] [-s string] dburl < sql_command_file\n";
     print "\n";
     print "See 'man $Global::progname' for the options\n"; }


sub debug {
=for pod2rst next-code-block: bash


.. code-block:: perl

     # Returns: N/A
 =for pod2rst next-code-block: bash
 
     $Global::debug or return;
 =for pod2rst next-code-block: bash
 
     @_ = grep { defined $_ ? $_ : "" } @_;
     print @_; }


$::opt_skip_first_line = $::opt_shebang = 0;

